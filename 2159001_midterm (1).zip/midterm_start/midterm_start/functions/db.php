<?php

$host = "localhost";
$user = "root";
$password = "";
$db = "2023_midterm";

$conn = new mysqli($host, $user, $password, $db);

var_dump($conn);


?>