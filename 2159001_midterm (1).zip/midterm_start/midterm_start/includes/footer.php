<footer class="bg-dark text-light mt-5 pt-4 pb-5"> <!-- start of footer, move to footer.php -->

    <div class="container pt-3 pb-5">
        <h3><i class="fas fa-bomb    "></i> ITEC Meme University
            <?php echo Date("Y"); ?>
        </h3>
    </div>
</footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.1/umd/popper.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/js/bootstrap.min.js"></script>
</body>

</html>