<?php include 'includes/header.php';
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    var_dump($name, $email, $message);
}
?>

<div class="container">
    <h2>Contact</h2>
    <div>
        <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3937.3822031769428!2d105.72864547605823!3d9.29936138469615!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31a10974eee85a09%3A0x5f71e8e2dd655d24!2zMjc5IFRy4bqnbiBIdeG7s25oLCBQaMaw4budbmcgMSwgQuG6oWMgTGnDqnUsIFZpZXRuYW0!5e0!3m2!1sen!2s!4v1685434265199!5m2!1sen!2s"
            width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
    <div class="mt-4"
        style="border:10px solid lightgreen ;color: black;padding:10px;border-radius:10px; text-align: center;">
        <h4>Contact Us</h4>
        <form method="POST" style="text-align:left; padding:10px">
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" id="name" name="name" required
                    style="border: 1px solid black; ">
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email" name="email" required
                    style="border: 1px solid green;">
            </div>
            <div class="form-group">
                <label for="message">Message</label>
                <textarea class="form-control" id="message" name="message" rows="5" required
                    style="border: 1px solid green;"></textarea>
            </div>
            <button type="submit" name="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</div>

<?php
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    echo "<h5>Form values:</h5>";
    echo "<p>Name: $name</p>";
    echo "<p>Email: $email</p>";
    echo "<p>Message: $message</p>";
}
?>

<?php include 'includes/footer.php'; ?>