import org.junit.Test;
import static org.junit.Assert.*;

public class FactorialCalculatorTest {
    
    @Test(expected = IllegalArgumentException.class)
    public void testCalculateFactorial_NegativeInput() {
        FactorialCalculator.calculateFactorial(-1);
    }

    @Test
    public void testCalculateFactorial_ZeroInput() {
        assertEquals(1, FactorialCalculator.calculateFactorial(0));
    }
    
    @Test
    public void testCalculateFactorial_OneInput() {
        assertEquals(1, FactorialCalculator.calculateFactorial(1));
    }
    
    @Test
    public void testCalculateFactorial_PositiveInput() {
        assertEquals(120, FactorialCalculator.calculateFactorial(5));
    }
}
