public class Client {
 
    public static void main(String[] args) {
        System.out.println("NORMAL EMPLOYEE: ");
        EmployeeComponent employee = new EmployeeConcreteComponent("Hoang");
        employee.showBasicInfo();
        employee.doTask();

        EmployeeComponent employee_1=new EmployeeConcreteComponent("Tien");
        System.out.println("\nTEAM LEADER: ");
        EmployeeComponent teamLeader = new TeamLeader(employee_1);
        teamLeader.showBasicInfo();
        teamLeader.doTask();
        
        EmployeeComponent employee_2=new EmployeeConcreteComponent("Phu");
        System.out.println("\nMANAGER: ");
        EmployeeComponent manager = new Manager(employee_2);
        manager.showBasicInfo();
        manager.doTask();
        
        System.out.println("\nTEAM LEADER AND MANAGER: ");
        EmployeeComponent teamLeaderAndManager = new Manager(teamLeader);
        teamLeaderAndManager.showBasicInfo();
        teamLeaderAndManager.doTask();
    }
}