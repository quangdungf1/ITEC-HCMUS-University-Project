package model;
public class Rental {
    // Private member variables for storing movie and days rented
    private Movie movie;
    private int daysRented;

    // Constructor to initialize the rental with a movie and days rented
    public Rental(Movie movie, int daysRented) {
        this.movie = movie;
        this.daysRented = daysRented;
    }

    // Getter method to retrieve the number of days rented for this rental
    public int getDaysRented() {
        return daysRented;
    }

    // Getter method to retrieve the movie associated with this rental
    public Movie getMovie() {
        return movie;
    }
}
