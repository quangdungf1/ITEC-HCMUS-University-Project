package model;
public class Movie {
    // Constants representing the different movie price codes
    public static final int CHILDRENS = 2;
    public static final int REGULAR = 0;
    public static final int NEW_RELEASE = 1;

    // Private member variables for storing movie title and price code
    private String title;
    private int priceCode;

    // Constructor to initialize the movie with a title and price code
    public Movie(String title, int priceCode) {
        this.title = title;
        this.priceCode = priceCode;
    }

    // Getter method to retrieve the movie's price code
    public int getPriceCode() {
        return priceCode;
    }

    // Setter method to set the movie's price code
    public void setPriceCode(int priceCode) {
        this.priceCode = priceCode;
    }

    // Getter method to retrieve the movie's title
    public String getTitle() {
        return title;
    }
}
