package model;
import java.util.*;

// Interface for the Strategy Design Pattern (PriceCalculator)
interface PriceCalculator {
    double calculateRentalAmount(int daysRented);
}

// Concrete implementation for Regular movies
class RegularPriceCalculator implements PriceCalculator {
    @Override
    public double calculateRentalAmount(int daysRented) {
        double amount = 2;
        if (daysRented > 2) {
            amount += (daysRented - 2) * 1.5;
        }
        return amount;
    }
}

// Concrete implementation for New Release movies
class NewReleasePriceCalculator implements PriceCalculator {
    @Override
    public double calculateRentalAmount(int daysRented) {
        return daysRented * 3;
    }
}

// Concrete implementation for Children's movies
class ChildrensPriceCalculator implements PriceCalculator {
    @Override
    public double calculateRentalAmount(int daysRented) {
        double amount = 1.5;
        if (daysRented > 3) {
            amount += (daysRented - 3) * 1.5;
        }
        return amount;
    }
}

// Definition of the Customers class
public class Customers {

    private String name;
    private Vector<Rental> rentals = new Vector<>();
    private PriceCalculator priceCalculator; // Strategy instance

    public Customers(String name, PriceCalculator priceCalculator) {
        this.name = name;
        this.priceCalculator = priceCalculator;
    }

    public void addRental(Rental rental) {
        rentals.addElement(rental);
    }

    public String getName() {
        return name;
    }

    public void setPriceCalculator(PriceCalculator priceCalculator) {
        this.priceCalculator = priceCalculator;
    }
	
    // public String statement() {
    //     double totalAmount = 0;
    //     int frequentRenterPoints = 0;
    //     Enumeration<Rental> rentalEnum = rentals.elements();
    //     String result = "Rental Record for " + getName() + "\n";

    //     while (rentalEnum.hasMoreElements()) {
    //         Rental each = rentalEnum.nextElement();
    //         double thisAmount = priceCalculator.calculateRentalAmount(each.getDaysRented());
    //         frequentRenterPoints += calculateFrequentRenterPoints(each);

    //         result += "\t" + each.getMovie().getTitle() + "\t" + String.valueOf(thisAmount) + " \n";
    //         totalAmount += thisAmount;
    //     }

    //     result += "Amount owned is " + String.valueOf(totalAmount) + "\n";
    //     result += "You earned " + String.valueOf(frequentRenterPoints) + " frequent renter points";
    //     return result;
    // }
	public String htmlStatement() {
        double totalAmount = 0;
        int frequentRenterPoints = 0;
        Enumeration<Rental> rentalEnum = rentals.elements();
        StringBuilder result = new StringBuilder("<html><body><h2>Rental Record for " + getName() + "</h2>");

        while (rentalEnum.hasMoreElements()) {
            Rental each = rentalEnum.nextElement();
            double thisAmount = priceCalculator.calculateRentalAmount(each.getDaysRented());
            frequentRenterPoints += calculateFrequentRenterPoints(each);

            result.append("\t<p>").append(each.getMovie().getTitle()).append(": ").append(String.valueOf(thisAmount)).append("</p>\n");
            totalAmount += thisAmount;
        }

        result.append("<p>Amount owned is ").append(String.valueOf(totalAmount)).append("</p>\n");
        result.append("<p>You earned ").append(String.valueOf(frequentRenterPoints)).append(" frequent renter points</p>");
        result.append("</body></html>");
        return result.toString();
    }
    private int calculateFrequentRenterPoints(Rental rental) {
        int frequentRenterPoints = 1;

        if ((rental.getMovie().getPriceCode() == Movie.NEW_RELEASE) && (rental.getDaysRented() > 1))
            frequentRenterPoints++;

        return frequentRenterPoints;
    }
}
