# first: yarn add styled-components react-icons axios 
#second: lấy file package.json
#3: npm install react-slick slick-carousel
#4: npm start
