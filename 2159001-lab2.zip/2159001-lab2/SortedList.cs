using System;
namespace SortedList_s
{
    class SortedList
    {
        private int[] numbers;
        private Random random;

        public SortedList(int size)
        {
            numbers = new int[size];
            random = new Random();
            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = GenerateRandomNumber();
            }
        }

        public void SelectionSort()
        {
            for (int i = 0; i < numbers.Length - 1; i++)
            {
                int min = i;
                for (int j = i + 1; j < numbers.Length; j++)
                {
                    if (numbers[j] < numbers[min])
                    {
                        min = j;
                    }
                }
                int temp = numbers[i];
                numbers[i] = numbers[min];
                numbers[min] = temp;
            }
        }

        public void BubbleSort()
        {
            bool swapped = false;
            int swappedCounter = 0;
            do
            {
                swapped = false;
                for (int i = 0; i < numbers.Length - 1; i++)
                {
                    if (numbers[i] > numbers[i + 1])
                    {
                        int temp = numbers[i];
                        numbers[i] = numbers[i + 1];
                        numbers[i + 1] = temp;
                        swapped = true;
                        swappedCounter++;
                    }
                }
            } while (swapped);
            Console.WriteLine($"Bubble sort swapped {swappedCounter} times.");
        }

        public void Print()
        {
            Console.WriteLine("Sorted List:");
            foreach (var number in numbers)
            {
                Console.Write(number + " ");
            }   
            Console.WriteLine();
        }

        private int GenerateRandomNumber()
        {
            return random.Next(1, 999);
        }
    }
}
