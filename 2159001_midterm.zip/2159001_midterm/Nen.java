public class Nen implements BasicShapeComponent {
    private BasicShapeComponent component;
    private String loaiNen;
    private String mauNen;
    private String cachTo;

    public Nen(BasicShapeComponent component, String loaiNen, String mauNen,String cachTo) { 
        this.component = component;
        this.loaiNen = loaiNen;
        this.mauNen = mauNen;
        this.cachTo = cachTo;
    }
    @Override
    public void draw(){
        component.draw();
        System.out.println(" Background " + loaiNen + " color " + mauNen+" draw  " + cachTo);
    }
}
