public class DrawingMainProgram {
    public static void main(String[] args) {
        // Tạo đối tượng hình vuông
        BasicShapeComponent square = new BasicShape("Square");
        square = new Nen(square, "monochrome", "white", "recursive bowl");
        square.draw();

        // Tạo đối tượng hình tròn
        BasicShapeComponent circle = new BasicShape("Circle");
        circle = new Vien(circle, "dashed", "black");
        circle = new Nen(circle, "no background", "no", "no");
        circle.draw();

        // Tạo đối tượng hình tròn khác
        BasicShapeComponent anotherCircle = new BasicShape("Circle");
        anotherCircle = new Vien(anotherCircle, "dashed line", "red");
        anotherCircle = new Nen(anotherCircle, "radial gradient", "yellow-white", "no recursion");
        anotherCircle.draw();
    }
}