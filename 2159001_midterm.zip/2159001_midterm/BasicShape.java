
public class BasicShape implements BasicShapeComponent
{
    private String name ;
    public BasicShape(String name) {
        this.name = name;
    }
    @Override
    public void draw(){
        System.out.println(name);
    }   
}
   

    
