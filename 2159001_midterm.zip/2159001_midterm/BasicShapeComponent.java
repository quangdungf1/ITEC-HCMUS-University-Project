

public interface BasicShapeComponent
{
    void draw();
}
   

    
