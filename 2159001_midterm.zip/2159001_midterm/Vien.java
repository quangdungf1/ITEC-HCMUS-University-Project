public class Vien implements BasicShapeComponent {
    private BasicShapeComponent component;
    private String loaiNet;
    private String mauNet;

    public Vien(BasicShapeComponent component, String loaiNet, String mauNet) 
    {
        this.component = component;
        this.loaiNet = loaiNet;
        this.mauNet = mauNet;
    }
    @Override
    public void draw(){
        component.draw();
        System.out.println("Outline " + loaiNet + " color " + mauNet);
    }
}
