<?php


Router::get("hello", function() {
    echo "<h1>hello world<h1>";
});

Router::get("", function() {
    $home = new Home();
    $home->index();
    var_dump($home->req);
    var_dump($home->params);
});

Router::get("login", function() {
   $user = new User;
   $user->getLogin();
});

Router::post("create_user", function() {
    $user = new User;
    $user->createUser();
});

Router::get("contact", function() {
    include "views/contact.php";
});

Router::post("login", function() {
    $user = new User;
    $user->login();

});

if(Router::$found === false) {
    include "views/_404.php";
}