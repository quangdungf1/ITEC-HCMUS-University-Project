<?php include "views/includes/header.php";?>

    <div class="jumbotron">
        <div class="container">
        <h1 class="display-4">404 page not found</h1>
        <p class="lead">You are lost</p>
        <hr class="my-4">
        <p>return <a href="index.php">home</a></p>
        </div>
    </div>

<?php include "views/includes/footer.php"; ?>