<footer class="pt-3 pb-5 mt-4 bg-dark text-light">
        <div class="container pb-4 pt-3">
            <h3><i class="fas fa-cogs    "></i> ITEC MVC 2023</h3>
        </div>
    </footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.1/umd/popper.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/js/bootstrap.min.js"></script>
</body>
</html>